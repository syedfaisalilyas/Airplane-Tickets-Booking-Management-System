import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import scipy as sp
# Load the CSV file into a DataFrame
file_path = "Example.csv"
data = pd.read_csv(file_path)

# Remove extra spaces from column names
data.columns = data.columns.str.strip()

def draw_graph_with_title(graph, title, color):
    plt.figure(figsize=(10, 8))
    pos = nx.spring_layout(graph)
    nx.draw(graph, pos=pos, with_labels=True, node_color=color, font_weight='normal')
    plt.title(title)
    plt.text(0.5, -0.1, title, ha='center', fontsize=12, transform=plt.gca().transAxes)
    plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)
    plt.tight_layout()
    plt.show()

# Create a directed graph
directed_graph = nx.from_pandas_edgelist(
    data, source='Source_Country', target='Destination_Country', create_using=nx.DiGraph()
)
draw_graph_with_title(directed_graph, 'Directed Graph', 'skyblue')

# Create an undirected graph
undirected_graph = nx.from_pandas_edgelist(
    data, source='Source_Country', target='Destination_Country'
)
draw_graph_with_title(undirected_graph, 'Undirected Graph', 'lightgreen')

# Create a pseudo graph (allows multiple edges between nodes)
pseudo_graph = nx.MultiGraph()
pseudo_graph.add_edges_from(
    zip(data['Source_Country'], data['Destination_Country'])
)
draw_graph_with_title(pseudo_graph, 'Pseudo Graph', 'lightcoral')

# Create a random graph for cyclic demonstration
random_graph = nx.gnm_random_graph(len(data), len(data) // 2)
draw_graph_with_title(random_graph, 'Random Graph (Cyclic Demo)', 'lightpink')

# Create a complete graph
complete_graph = nx.complete_graph(len(data))
draw_graph_with_title(complete_graph, 'Complete Graph', 'lightyellow')

# Additional Graphs
try:
    # Create a connected graph
    connected_graph = nx.connected_watts_strogatz_graph(10, 3, 0.1)
    draw_graph_with_title(connected_graph, 'Connected Graph', 'lightgray')
except Exception as e:
    print(f"Connected Graph: {e}")

# ... Continue with other graph creation methods following a similar structure
# Create a disconnected graph
try:
    disconnected_graph = nx.disjoint_union(nx.complete_graph(5), nx.complete_graph(5))
    draw_graph_with_title(disconnected_graph, 'Disconnected Graph', 'lightcyan')
except Exception as e:
    print(f"Disconnected Graph: {e}")

# Create a bipartite graph
try:
    bipartite_graph = nx.complete_bipartite_graph(3, 5)
    draw_graph_with_title(bipartite_graph, 'Bipartite Graph', 'orange')  # Changed color to 'orange'
except Exception as e:
    print(f"Bipartite Graph: {e}")


# Create a simple graph from the first few rows of the dataset
try:
    simple_edges = [(row['Source_Country'], row['Destination_Country']) for _, row in data.head(5).iterrows()]
    simple_graph = nx.Graph(simple_edges)
    draw_graph_with_title(simple_graph, 'Simple Graph', 'lightgreen')
except Exception as e:
    print(f"Simple Graph: {e}")

#weighted graph
try:
    # Check if 'Flight_Number' column contains numeric values
    if 'Flight_Number' in data.columns and pd.to_numeric(data['Flight_Number'], errors='coerce').notnull().all():
        # Convert 'Flight_Number' column to numeric values
        data['Flight_Number'] = pd.to_numeric(data['Flight_Number'], errors='coerce')

        weighted_edges = [
            (row['Source_Country'], row['Destination_Country'], row['Flight_Number']) for _, row in data.iterrows()
        ]
        weighted_graph = nx.Graph()
        weighted_graph.add_weighted_edges_from(weighted_edges)

        # Draw the weighted graph
        draw_graph_with_title(weighted_graph, 'Weighted Graph', 'lightblue')
    else:
        raise ValueError("Column 'Flight_Number' either not found or contains non-numeric values.")
except Exception as e:
    print(f"Weighted Graph: {e}")

# Create an unweighted graph
try:
    unweighted_edges = [(row['Source_Country'], row['Destination_Country']) for _, row in data.head(5).iterrows()]
    unweighted_graph = nx.Graph(unweighted_edges)
    draw_graph_with_title(unweighted_graph, 'Unweighted Graph', 'lightgreen')
except Exception as e:
    print(f"Unweighted Graph: {e}")

# Create a cyclic graph
try:
    cyclic_graph = nx.cycle_graph(5)
    draw_graph_with_title(cyclic_graph, 'Cyclic Graph', 'lightcoral')
except Exception as e:
    print(f"Cyclic Graph: {e}")

# Create a multigraph
try:
    multigraph = nx.MultiGraph()
    multigraph.add_edges_from([(1, 2), (1, 2), (1, 2), (2, 3), (3, 4)])
    draw_graph_with_title(multigraph, 'Multigraph', 'lightyellow')
except Exception as e:
    print(f"Multigraph: {e}")

# Create a directed acyclic graph (DAG)
try:
    dag = nx.random_tree(10, seed=42)
    draw_graph_with_title(dag, 'Directed Acyclic Graph', 'lightpink')
except Exception as e:
    print(f"DAG: {e}")

# Create a random graph
try:
    random_graph = nx.gnm_random_graph(10, 15)
    draw_graph_with_title(random_graph, 'Random Graph', 'lightgray')
except Exception as e:
    print(f"Random Graph: {e}")

# Create a line graph
try:
    line_graph = nx.line_graph(nx.complete_graph(5))
    draw_graph_with_title(line_graph, 'Line Graph', 'lightcyan')
except Exception as e:
    print(f"Line Graph: {e}")
